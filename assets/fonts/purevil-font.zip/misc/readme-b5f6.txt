Congratulations, you have successfully downloaded Purevil Demo Version font file! 
This font is provided to you by Burntilldead – Illustrator & Type Foundry

---

Follow the link to download more freebies and other great stuff:
https://www.burntilldeadstudio.com 

Don't forget to purchase the commercial license here:
1. https://creativemarket.com/Burntilldead
2. https://fontbundles.net/burntilldead
3. https://www.myfonts.com/foundry/Burntilldead/
4. https://www.creativefabrica.com/designer/burntilldead/
5. https://elements.envato.com/user/Eric_Burntilldead

Feel free to email me if you have any question or license detail:
eric@burntilldead.net

---

How to install this font on your computer?

For Windows 7 / Vista users:

- Right-click the font file(s) and choose "Install".

For users of the previous Windows versions:

- Copy the included file(s) into a default Windows font folder 
  (usually C:\WINDOWS\FONTS or C:\WINNT\FONTS)

For Mac users:

Mac OS X 10.3 or above (including the FontBook)

- Double-click the font file and hit "Install font" button at 
  the bottom of the preview.

Mac OS X

- Either copy the font file(s) to /Library/Fonts (for all users), 
  or to /Users/Your_username/Library/Fonts (for you only).

Mac OS 9 or earlier

- You have to convert the font file(s) you have downloaded. 
  Drag the font suitcases into the System folder. The system 
  will propose you to add them to the Fonts folder.

For Linux users:

- Copy the font file(s) to /USR/SHARE/FONTS

